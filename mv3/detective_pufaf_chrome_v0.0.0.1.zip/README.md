# Version Chrome
Version de l'extension compatible avec Google Chrome, utilisant un mv3 (manifest version 3).